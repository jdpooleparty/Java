package yourworkhere;

public class Account {
	
	/*confused about instruction in task 2.1.1 : it begins by saying that
	I should mark the fields that I defined in nthe Account class private. 
	I do not know how to mark specific fields as private, as when I tried
	to change String accountID to private String accountID, it threw an
	error. I will leave it as it is for now, but I suspect I may need to come
	back and change something for this program to work.
	*/
		private String accountID = "121170028";
		private Double balance = 1993.22;
		private String accountType = "Checking";
		private String firstName = "Jeffrey";
		private String lastName = "Fallon"
				;
	
		public String getAccountID() {
			return this.accountID;
		}
		public void setAccountID(String accountID) {
			this.accountID = accountID;
		}
		public Double getBalance() {
			return this.balance;
		}
		public void setBalance(Double balance) {
			this.balance = balance;
		}
		public String getAccountType() {
			return this.accountType;
		}
		public void setAccountType(String accountType) {
			this.accountType = accountType;
		}
		public String getFirstName() {
			return this.firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getLastName() {
			return this.lastName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		
		}
		
	}
	
