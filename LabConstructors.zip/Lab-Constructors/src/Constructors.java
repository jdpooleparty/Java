
public class Constructors {
	
	public Constructors() {
		System.out.println("Default constructor ran.");
	}

	
	public Constructors(int value) {
		System.out.println(value);
	}
	
	public static void main(String[] args) {
		// create instances here
		Constructors Q = new Constructors(2445);
		
		//use the no-arg constructor
		Constructors QNoArg = new Constructors();

	}

}
