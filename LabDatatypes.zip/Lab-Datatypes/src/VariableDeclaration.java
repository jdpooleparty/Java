
public class VariableDeclaration {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean on = false;
		System.out.println(on);
		
		short s = 16;
		System.out.println(s);
		
		int i = -32;
		System.out.println(i);
		
		float f = 3830.203842f;
		System.out.println(f);
		
		long l = 54135454354546L;
		System.out.println(l);
		
		char c = 'a';
		System.out.println(c);
	}

}
