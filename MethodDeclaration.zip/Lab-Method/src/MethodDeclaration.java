
public class MethodDeclaration {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//create a class instance
		MethodDeclaration md= new MethodDeclaration();
		
		//call your first method here
		md.talk();
		
		//call your second method here
		int value = 150;
		int sameValue = md.getInt(value);
		
		System.out.println(sameValue);
		
		//call your third method here
		System.out.println(md.sum(5, 12, 144.9985445));
	
	

	}

		//create your first method here
	public void talk() {
		System.out.println("Inside of the talk method");
	}
	
		//create your second method here
	public int getInt(int input) {
		return input;
		
	}
		//create your third method here
	public double sum(int x, int y, double z) {
		return x + y + z;
	
	}
}
