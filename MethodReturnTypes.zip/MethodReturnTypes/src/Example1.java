
public class Example1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		String val = stringReturner();
		System.out.println(val);
	}
	public static String stringReturner() {
		return "Hello";
	}
	

}
